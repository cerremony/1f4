#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//#define ENGLISH
#define ALBANIAN

#ifdef ALBANIAN
	char *welcome = "Miresevini te programit e ruajtje strings pafund.";
	char *prompt = "Ju lutemi te dhena nje fjale te vetme: ";
#else
	char *welcome = "Welcome to the infinite string storage program.";
	char *prompt = "Please input a sinlge word: ";
#endif

typedef struct NODE {
	char word[256];
	struct NODE* next;
} node;

node *root=NULL;

void printList();

int main() {
	char str[100], temp[100];
	printf("%s\n", welcome);
	while(1){
		node *new, *current;
		new = (node *)malloc(sizeof(node));
		printf("%s", prompt);
		fgets(str, 100, stdin);
		sscanf(str, "%s", temp);
		if(strcmp(temp, "***END***") == 0) break;
		strcpy(new->word, temp);
		new->next = NULL;
		if(root == NULL){
			root = new;
			current = new;
		}
		else{
			current->next = new;
			current = new;
		}
	}
	printList();
	return EXIT_SUCCESS;
}

void printList(){
	node *n = root;
	if (n == NULL) printf("List is empty."); 
	while (n != NULL){
		printf("%s ", n->word);
		n = n->next;
	}
	printf("\n");	
	return;
}
