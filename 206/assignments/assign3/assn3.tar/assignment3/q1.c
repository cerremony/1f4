#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]){
	FILE *data = fopen(argv[1], "rt");
	if (data == NULL){
		printf("No data\n");
		return EXIT_FAILURE;
	}
	float sum, size, average;
	int value = 0;
	while(1){
		int c = fgetc(data);
		while(c != ',' && c != EOF){
			printf("%c", c);
			c = fgetc(data);
		}
		if (c == EOF) break;
		printf("  ");
		sum = size = 0;
		while(1 == fscanf(data, "%d%*c", &value)){
			sum += value;
			size++;
		}
		average = sum/size;
		printf("%.2f\n", average);
	}
	fclose(data);
	return EXIT_SUCCESS;
}
