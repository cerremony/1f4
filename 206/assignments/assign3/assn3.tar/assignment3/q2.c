#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void main() {
	char *prompt, command[100];
	sprintf(prompt, "[Super Shell!!]: ");
	int key;
	size_t len;

	while(1) {
		printf("%s", prompt);
		gets(command);
		if (strcasecmp(command, "QUIT") == 0) { return; } 
		else if (strncasecmp(command, "SET PROMPT", 10) == 0) {
			len = strlen(command);
			if (len > 11) {
				if(command[len-1] == '\n') {
					command[len-1] = '\0';
					len--;
				}
				prompt = command + 11;
				len -= 11;
			}
		}
		else { system(command); }
	}
}
